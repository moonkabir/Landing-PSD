/* ==========================================================================
   Theme name:App landing;
   Authore name:Moon kabir;
   Authore URI:;
   ========================================================================== */
/* ==========================================================================
   Index
   ========================================================================== */
// 1.mean-menu(header)
// 2.sticky-menu(header)
// 3.ui-tabs(Awesome-apps-feature)
// 4.tiny-slider(Awesome-apps-feature)
// 5.tiny-slider2(it-awesome-home23)
// 6.magnific-popup(How-Does-this-App-Work)
// 7.swiper slider(app-screenshot)
// 7.2swiper slider(app-screenshot2)
// 7.3swiper-slider(blog-details)




(function($) {
    "use strict";
    $(document).ready(function() {
        // ============1.mean-menu(header)============
        $('nav').meanmenu({
            meanMenuContainer: '.menu-area',
            meanScreenWidth: "991",
            onePage: true
        });
        // ============2.sticky-menu(header)=============
        $("header").sticky();
        // ============3.ui-tabs(Awesome-apps-feature)=============
        if ($('#tabs').length) {
            $("#tabs").tabs({
                show: { effect: "blind", duration: 800 }
            });
        }
        // ==============4.tiny-slider(Awesome-apps-feature)===============
        if ($(window).width() > 768) {
            var slider = tns({
                container: '#my-slider',
                axis: "vertical",
                controlsText: ["<i class='fas fa-chevron-down'></i>", "<i class='fas fa-chevron-up'></i>"],
                autoplayHoverPause: true,
                autoplayTimeout: 1000,
                items: 3,
            });
        } else {
            var slider = tns({
                container: '#my-slider',
                axis: "horizontal",
                controls: false,
                autoplayHoverPause: true,
                autoplayTimeout: 1000,
                mouseDrag: true,
                items: 1,
            });
        }
        //============== 5.tiny-slider2(it-awesome-home23)========== 
        if ($('.clients-slider').length) {
            var slider2 = tns({
                container: '.clients-slider',
                // swipeAngle: false,
                items: 1,
                speed: 400,
                mouseDrag: true,
                controls: false,
                nav: true,
                navPosition: 'bottom',
            });
        }
        // ================6.magnific-popup(How-Does-this-App-Work)================
        $('.popup-youtube').magnificPopup({
            disableOn: 700,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: true,
            iframe: {
                patterns: {
                    youtube: {

                        src: 'https://www.youtube.com/watch?v=AGBjI0x9VbM' // URL that will be set as a source for iframe.
                    }
                },
                srcAction: 'popup-youtube', // Templating object key. First part defines CSS selector, second attribute. "iframe_src" means: find "iframe" and set attribute "src".
            },
            fixedContentPos: false
        });
        // ============== 7.swiper slider(app-screenshot) ==========
        var mySwiper = new Swiper('#app-screen', {
            loop: true,
            slidesPerView: 5,
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                480: {
                    slidesPerView: 1,
                },
                640: {
                    slidesPerView: 2,
                },
                767: {
                    slidesPerView: 2,
                },
                900: {
                    slidesPerView: 3,
                }
            }
        });
        // ============== 7.2swiper slider(app-screenshot2) ==========
        var mySwiper = new Swiper('#app-screen2', {
            loop: true,
            slidesPerView: 5,
            navigation: {
                nextEl: '.swiper-button-prev',
                prevEl: '.swiper-button-next',
            },

            effect: 'coverflow',
            coverflowEffect: {
                rotate: 0,
                stretch: 50,
                depth: 250,
                modifier: .4,
                slideShadow: false,
            },
            breakpoints: {
                320: {
                    slidesPerView:  1,
                    effect:'slide',
                },
                480: {
                    slidesPerView: 2,
                    effect:'slide',
                },
                640: {
                    slidesPerView: 3,
                },
                767: {
                    slidesPerView: 3,
                }
            }
        });
        // ============== 7.3swiper-slider(blog-details) ==========
        var mySwiper = new Swiper('#releted-post', {
            loop: true,
            slidesPerView: 2,
        });


    }); //ready Function


    $(window).on('load', function() {

    });
})(jQuery)